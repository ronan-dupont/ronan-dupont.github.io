from matplotlib.pylab import *
#import sympy as sp
from scipy import interpolate
import numpy as np
import random
import matplotlib.pyplot as plt
from my_swan_function import run_swan
from my_xbeach_function import run_xbeach
from bathy_types import load_bathy
from functionnal_types import load_functionnal
import pandas as pd
import os as os
from scipy.special import erf
from utils_functions import *
import subprocess
import warnings
warnings.filterwarnings("ignore")

######
# Params #
######

# ----- plot params
np.random.seed(7)
#ion()
fig, axs = subplots(6, 1, figsize=(12, 10))
fig2 = figure(figsize=(14,6))
ax = fig2.gca()
theta0 = 0
width = 2
lstyle =["-","-.",":","-"]
c=['lightgreen','red','blue', 'black']
repertoire = "Results"
psi_datas= "datas_psi/"
if not os.path.exists(repertoire):
     os.makedirs(repertoire)

#Parametres de simulation a post-traiter
leg = ['$\psi_0$ the initial bathymetry [m]','$H(x)$ the wave height from SWAN [m]','$\psi$ the final bathymetry [m]',]
lstyle=["-","--","-.",":","-."]
color=["darkred","darkgreen","darkgoldenrod","slateblue","navy","black"]
leg_hydro = ["Shoaling","SWAN","XBeach"]
titlesize=18
laabelsize=18
legendsize=16
width=2

xlb1='Distance from deep sea [m]'
ylb1="Height $[m]$"
filename_save="swan_output_HSIG.dat"

# ----- load params
param = loadtxt('params.dat')

# ----- hydro-morpho params
g = 9.81
T0 = float(param[0])
Hmax = float(param[1])
h0 = float(param[2])
C0 = 9.81/(2*pi)*T0
sigma0 = 2*pi/T0
gamma = float(param[11])
seuil = 1e-15

niter=int(param[4])
ifre=50
time = linspace (0,niter,niter+1)
static=int(param[10])

if static==0:
     H0 = ones(len(time))*Hmax
else:
     H0 = create_forcing(time, max(time)/2, 2*10**2,Hmax, -1e-4)


# ----- geometric params
bathy_type = int(param[6])
nwater = int(param[3])
ntot = nwater + 10
x = linspace(0,ntot-1,ntot)
xstep = x[1]-x[0]


x, h0, ntot, psi, psif, bool_H0, HRMS = load_bathy(bathy_type, x, h0, nwater, ntot, seuil, psi_datas)     
h = h0 - psi

#plot(x,h)
#show()

if not(bool_H0):
     if static==0:
          H0 = ones(len(time))*Hmax
     else:
          H0 = create_forcing(time, max(time)/2, 2*10**2,Hmax, -1e-4)


psi0 = psi.copy()

slope_max = float(param[7])
Mslope = slope_max * ones(ntot)

# ----- hydro calculation
k = k_guo(h,sigma0,g)
H,Hpsi = calc_H(H0[0], k,h0-psi,gamma)

# Last hydro model params
dwin = 5*xstep
Nwin = int(floor(dwin/xstep))
#print(Nwin)


######################
####### Verification ########
######################
mobility = float(param[5])

rho0=mobility*ones(ntot)
depl_max=0.05     #max depl par iter
depl_total_max_absolu=1  #max cumul en m
max_loss_depth=0.5  # % perte profondeur max

minidepth=0.1   # si<minidepth:  pas d'interaction


id_cost= param[8]

id_hydro = param[9]
id_hydro = int(id_hydro)
"""
if id_hydro==1: #SWAN
     #subprocess.run(["module","load","use.own"])
     #subprocess.run(["module","load","swan"])
"""

leg[1] = "$H(x)$ the wave height from "+leg_hydro[id_hydro]+ " [m]"

histJ=[]
sand0=trapz(psi0,x)

for itera in range(niter):
    h_t = h0-psi
    if(id_hydro==0):
          xS_t, xB_t, nbS_t, nbB_t = shoreline(h_t, x) # shoreline calculation
          gamma = 0.55
          k_t, C_t, Cg_t, H_t, xB_t, nbB_t, H_S, tab_xB_start, tab_nbB_start, tab_xB_end, tab_nbB_end, Hw, tab_ibreak = shoaling_window_RONAN(nbS_t, nbB_t, h_t, sigma0, C0, theta0, H0[itera], x, gamma, Nwin, g) 
    elif(id_hydro==1):
         gamma = 0.45
         H_t, T0_t = run_swan(H0[itera], T0, psi, x, h0, gamma)   # hydro calculation
         H_t[isnan(H)] = 0 # put NaN to 0
         T0_t[abs(T0_t)<1e-10] = 0 # put 0 to NaN
         sigma0 = 2*pi/T0_t
         k_t = k_guo(h_t,sigma0,g)
    elif(id_hydro==2):        
         H_t, k_t, u_t,tau_t = run_xbeach(H0[itera], T0, psi, x, h0, gamma)   # hydro calculation
         H_t[isnan(H_t)] = 0 # put NaN to 0
         tau_t = abs(tau_t)
         u_t[h_t<0] = 0
         tau_t[h_t<0] = 0 
        
    dj, cost = load_functionnal(psi,H_t,id_cost)

    dj[0:2]=0 #2*dj[1]-dj[2]

    histJ.append(cost)
    savedj = dj.copy()

    ponderatau = ones(ntot)
    #ponderatau = (1/tau_t)**1
    ponderatau[H_t<=1] *= H_t[H_t<=1]
    #ponderatau/=max(ponderatau)
    ponderatau[ponderatau<0]=0
    
    ponderatau[h_t<=minidepth] = 0

    dumping=1/cosh(k_t*h_t)
    dumping*=(1-exp(-50*(x/ntot)**2))     #pas d'interaction si tres profond
    dumping[h_t<=minidepth]=0              #peu d'eau : pas de deplacement 
    dumping/=np.max(dumping)               #dumping borne par 1
    dumping[dumping<0]=0                   #tjs >=0 : entre 0 et 1
    dj*=-rho0*dumping*ponderatau                      #mobilite avant projection   
    
    for i in range(1,ntot-1):    #max deplacement per iteration  avt project
        dj[i]=max(min(dj[i],depl_max),-depl_max)
        dymax=max(0,-psi[i]+psi0[i]+depl_total_max_absolu)
        dymin=min(0,-psi[i]+psi0[i]-depl_total_max_absolu)
        dj[i]=max(min(dj[i],dymax),dymin)
        dj[i]=min(dj[i],psi0[i]-psi[i]+max_loss_depth*(np.max(psi0)-psi0[i]))
    
    psi1 = psi + dj              # pente max implicite avt project
    psi1= slopecst(psi1, Mslope, rho0, x) 
    dj= psi1-psi

    dj[0]=0                      #bords a zero
    dj[ntot-1]=0
    dj[h_t<=minidepth]=0         #peu d'eau : pas de deplacement

    diff=trapz(psi-psi0,x)       #contrainte conservation 
    dc = psi*diff
    dc[h_t<=minidepth]=0
    dc = normalise(dc)
    dj[h_t>=minidepth] = dj[h_t>=minidepth] - vdot2(dj, dc)*dc[h_t>=minidepth]   #project avant descente 

    dj[0]=0                      #bords a zero
    dj[ntot-1]=0
    dj[h_t<=minidepth]=0         #peu d'eau : pas de deplacement 
            
    d = dj
    
    psi += d
        
    psi[h_t>=minidepth]*=sand0/trapz(psi,x)       #contrainte conservation a posteriori
            
#%%
    if( itera%ifre == 0 or itera==niter-1 ):
        axs[0].clear()
        axs[1].clear()
        axs[2].clear()
        ax.clear()
        axs[3].clear()
        axs[4].clear()
        axs[5].clear()
        
        axs[0].set_title('Itération = '+str(itera)+" - H0 = "+str(round(H0[itera],2))+" m - T0 = "+str(T0)+' s - h0 = '+str(h0)+' m')
        print('iter=',itera,"sandstock=",sandstock(psi, psi0, x))

        axs[0].plot(dumping)
        axs[1].plot(savedj)
        axs[2].plot(d)
        axs[3].plot(psi-h0,color="black",label="Final Model")
        ax.plot(psi-h0,color="black",label="Final Model")
        axs[4].plot(ponderatau)
        axs[5].plot(ponderatau*dumping)
                
        
        axs[0].grid("on")
        axs[1].grid("on")
        axs[2].grid("on")
        axs[3].grid("on")
        ax.grid("on")
        axs[4].grid("on")
        axs[5].grid("on")
        
        axs[0].set_ylabel("fonction attenuation verticale")
        axs[1].set_ylabel("$dj$")
        axs[2].set_ylabel("$d$")
        axs[3].set_ylabel("$H$ and $\psi$")
        ax.set_ylabel("$H$ and $\psi$",fontsize=laabelsize)
        axs[4].set_ylabel("ponderaH")
        axs[5].set_ylabel("Upsilon *ponderaH")
        ax.set_xlabel(xlb1,fontsize=laabelsize)
        ax.set_title('Itération = '+str(itera)+" - H0 = "+str(round(H0[itera],2))+" m - T0 = "+str(T0)+' s - h0 = '+str(h0)+' m')
        
        axs[3].plot(H_t[H_t>=0],label="H "+leg_hydro[id_hydro])
        ax.plot(H_t[H_t>=0],label="H "+leg_hydro[id_hydro])
        axs[3].plot([0,x[-1]],[0,0],color="blue",linestyle="dashed")
        ax.plot([0,x[-1]],[0,0],color="blue",linestyle="dashed")
        axs[3].plot(psi0-h0,color="black",linestyle="dashed",label="Initial")
        ax.plot(psi0-h0,color="black",linestyle="dashed",label="Initial")
        axs[3].plot(psif-h0,color="red")
        ax.plot(psif-h0,color="red")
        ax.scatter(HRMS[0]-18.180,HRMS[1],color="blue")
        axs[3].legend()
        ax.legend(fontsize=legendsize,loc="best")
        xlabel(xlb1,fontsize=laabelsize)



        #axs[3].axis([x[psi<h0-20][-1], x[-1], psi[psi<h0-20][-1], max(H_t)*1.2+h0])
        fig.savefig(repertoire+'/'+'iter_'+str(itera)+".png")
        fig2.savefig(repertoire+'/'+'psi_iter_'+str(itera)+".png")
        savetxt(repertoire+'/'+'psi_'+str(itera)+".dat",psi)
        savetxt(repertoire+'/'+'H_'+str(itera)+".dat",H_t)    
        #plt.close()
        
#    print('iter=',itera)
       
#%%
figure()
plot(histJ)
savefig(repertoire+'/'+'Jhist='+str(itera)+".png")
savetxt(repertoire+'/'+"histJ.txt",histJ)


#############################################################################
#coder en detail pour verif
    # dc=psi.copy()   
    # diff=0
    # for i in range(ntot):
    #     diff+=psi[i]-psi0[i]
    # Ndc=0
    # for i in range(ntot):
    #     dc[i]=max(diff*psi[i],0)
    #     if(h_t[i]<=0):
    #         dc[i]=0
    #     Ndc+=dc[i]**2
    # dc/=max(Ndc,1.e-30)
    # ps=0
    # for i in range(ntot):
    #     ps+=dj[i]*dc[i]
    # dj-=ps*dc
    # dj[0]=0                      #bords à zero
    # dj[ntot-1]=0
    # dj[h_t<=minidepth]=0         #peu d'eau : pas de deplacement 
    # psi = psi1 - dj
##############################################################################
