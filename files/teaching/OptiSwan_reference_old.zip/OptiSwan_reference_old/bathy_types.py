from matplotlib.pylab import *

def load_bathy(bathy_type, x, h0, nwater, ntot, seuil, psi_datas):
     psif = ones(ntot) * NaN
     HRMS = ones(ntot) * NaN
     if bathy_type==0:
          psi = (x*h0/nwater)+seuil
          h = h0 - psi
          plot(psi)
     elif bathy_type==1:
          psi_lim = (x*h0/nwater)+seuil
          last_v = psi_lim[-1]
          psi = (last_v/ 0.99)*(0.99*(x/x[-1])**2) #concave
          h = h0 - psi
     elif bathy_type==2:      
          psi_lim = (x*h0/nwater)+seuil
          last_v = psi_lim[-1]
          psi= 2*psi_lim-(last_v/ 0.99)*(0.99*(x/x[-1])**2) #convexe
          h = h0 - psi
     elif bathy_type==3:      
          psi_lim=(x*h0/nwater)+seuil
          xgauss=5
          bosse_length=100 #épaisseur de la bosse
          bosse_size=1.5*1.1 #taille de la bosse
          bosse_profondeur=3 #profondeur de la bosse

          X=[]
          X=np.linspace(-xgauss,xgauss,bosse_length)
          psi0_f=pdf(X, -1)
          M=max(psi0_f)
          ind=np.where(psi0_f==M)[0][0]
          bosse_xmidle=np.where(psi_lim>(h0-bosse_profondeur))[0][0]

          bosse_xstart=bosse_xmidle-bosse_length//2 #position  x du commencement de la bosse
          bosse_hauteur=h0-bosse_profondeur+psi_lim[bosse_xmidle]
          bosse_xmidle=ind+bosse_xstart
          psi0_f=psi0_f*bosse_size/M
          psi0_f2=[]
          psi0_f2=[0 for i in range(bosse_xstart)]+list(psi0_f)
          psi0_f2 +=[0 for i in range(ntot-len(psi0_f2))]
          psi = array(psi0_f2+psi_lim)
          h = h0 - psi
     elif bathy_type==4:
          psi = loadtxt(psi_datas+'psi_LIP1B_initial'+'.dat')
          h0 = 4.1
          h = h0 - psi
          #nwater = int(param[3])
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          psif =  loadtxt(psi_datas+'psi_LIP1B_final'+'.dat')
          HRMS = loadtxt(psi_datas+'HRMS_LIP1B'+'.dat')
     elif bathy_type==5:      
          psi = loadtxt(psi_datas+'psi_T06_lineaire'+'.dat')
          h0 = 10
          h = h0 - psi
          ntot = len(psi)
          nwater = ntot - 10
          x = linspace(0,ntot-1,ntot)
     elif bathy_type==6:      
          psi = loadtxt(psi_datas+'psi_T06_concave'+'.dat')
          h0 = 10
          h = h0 - psi
          ntot = len(psi)
          nwater = ntot - 10
          x = linspace(0,ntot-1,ntot)
     elif bathy_type==7:      
          psi = loadtxt(psi_datas+'psi_T06_convexe'+'.dat')
          h0 = 10
          h = h0 - psi
          ntot = len(psi)
          nwater = ntot - 10
          x = linspace(0,ntot-1,ntot)
     elif bathy_type==8:      
          psi = loadtxt(psi_datas+'psi_T016_lineaire'+'.dat')
          h0 = 10
          h = h0 - psi
          ntot = len(psi)
          nwater = ntot - 10
          x = linspace(0,ntot-1,ntot)
     elif bathy_type==9:      
          psi = loadtxt(psi_datas+'psi_T016_concave'+'.dat')
          h0 = 10
          h = h0 - psi
          ntot = len(psi)
          nwater = ntot - 10
          x = linspace(0,ntot-1,ntot)
     elif bathy_type==10:      
          psi = loadtxt(psi_datas+'psi_T016_convexe'+'.dat')
          h0 = 10
          h = h0 - psi
          ntot = len(psi)
          nwater = ntot - 10
          x = linspace(0,ntot-1,ntot)
     elif bathy_type==11:      
          psi = loadtxt(psi_datas+'psi_LIP1C_initial'+'.dat')
          h0 = 4.1
          h = h0 - psi
          #H0 = ones(len(time))*0.6
          #nwater = int(param[3])
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          psif =  loadtxt(psi_datas+'psi_LIP1C_final'+'.dat')
          HRMS = loadtxt(psi_datas+'HRMS_LIP1C'+'.dat')

     elif bathy_type==12:      
          psi = loadtxt(psi_datas+'psi_LIP1C_final_interp'+'.dat')
          h0 = 4.1
          h = h0 - psi
          #H0 = ones(len(time))*0.6
          #nwater = int(param[3])
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          psif =  loadtxt(psi_datas+'psi_LIP1B_final'+'.dat')

     elif bathy_type==13:      
          psi = loadtxt(psi_datas+'psi_LIP1B_initial_interp'+'.dat')
          h0 = 4.1
          h = h0 - psi
          #H0 = ones(len(time))*0.6
          #nwater = int(param[3])
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          psif =  loadtxt(psi_datas+'psi_LIP1C_final'+'.dat')

     elif bathy_type==14:      
          psi = loadtxt(psi_datas+'psi_LIP1B_final'+'.dat')
          h0 = 4.1
          h = h0 - psi
          #H0 = ones(len(time))*0.6
          #nwater = int(param[3])
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          HRMS = loadtxt(psi_datas+'HRMS_LIP1B'+'.dat')
          
     elif bathy_type==15:      
          psi = loadtxt(psi_datas+'psi_LIP1C_final'+'.dat')
          h0 = 4.1
          h = h0 - psi
          #H0 = ones(len(time))*0.6
          #nwater = int(param[3])
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          HRMS = loadtxt(psi_datas+'HRMS_LIP1C'+'.dat')

     elif bathy_type==16:      
          psi = loadtxt(psi_datas+'psi_LIP1B_initial_interp_d1'+'.dat')
          h0 = 4.1
          h = h0 - psi
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          psif =  loadtxt(psi_datas+'psi_LIP1B_final'+'.dat')
          
     elif bathy_type==17:      
          psi = loadtxt(psi_datas+'psi_LIP1C_initial_interp_d1'+'.dat')
          h0 = 4.1
          h = h0 - psi
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          psif =  loadtxt(psi_datas+'psi_LIP1C_final'+'.dat')

     elif bathy_type==18:      
          psi = loadtxt(psi_datas+'bathy_copterI'+'.dat')
          h0 = 0.55
          h = h0 - psi
          ntot = len(psi)
          x = linspace(0,ntot-1,ntot)
          H0 = loadtxt(psi_datas+'H(t,0)_xb_2'+'.dat')
          return x, h0, ntot, psi, psif, H0, HRMS

     return x, h0, ntot, psi, psif, False, HRMS 
     
