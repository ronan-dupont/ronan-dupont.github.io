from matplotlib.pylab import *

def read(fname):
    file = open(fname,'r')
    x,z=[],[]
    lines = file.readlines()
    for i in range(2,len(lines)):
        line = lines [i]
        line = line.strip()
        line = line.split("    ")
        x . append(float ( line[0] ))
        z . append(float ( line[1] ))
    return x,z
def smooth(y, box_pts):
    box = ones(box_pts)/box_pts
    y_smooth = convolve(y, box, mode='same')
    return y_smooth

i = 0
figure(figsize=(12,4))
T = [0,18]
fName = ["HRMS"+".TEK"]
lab = ["Final data"]
c = ["blue"]
lst=["-"]
for i in range (len(fName)):
    fname = fName[i]
    x,z = read(fname)
    scatter(x,z,label=lab[i],linewidth = 2,color=c[i],linestyle=lst[i])
print(x)
print(x[1]-x[0])
plot([60,180],[0,0],color="cyan",linewidth = 2,linestyle="-.")
xlabel("x [m]")
ylabel('Depth [m]')
grid('on')
title("LIP-1B datas")
#axis([60,180,1.5-4,4-3.8])
legend()
show()
