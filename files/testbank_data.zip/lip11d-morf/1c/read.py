from matplotlib.pylab import *

def read(fname):
    file = open(fname,'r')
    x,z=[],[]
    lines = file.readlines()
    for i in range(2,len(lines)):
        line = lines [i]
        line = line.strip()
        line = line.split("    ")
        x . append(float ( line[0] ))
        z . append(float ( line[1] ))
    return x,z
def smooth(y, box_pts):
    box = ones(box_pts)/box_pts
    y_smooth = convolve(y, box, mode='same')
    return y_smooth

i = 0
figure(figsize=(12,4))
T = [0,18]
fName = ["ZT000"+str(1)+".TEK","ZT00"+str(13)+".TEK","hrms.tek"]
lab = ["initial","final","HRMS"]
c = ["black","red","blue"]
lst=[":","-","-"]

for i in range (0,len(fName)-1):
    fname = fName[i]
    x,z = read(fname)
    savetxt('psi_LIP1C_'+lab[i]+'.dat',smooth(z,4))
    plot(x,z-4.1,label=lab[i],linewidth = 2,color=c[i],linestyle=lst[i])
    
print(x)
print(x[1]-x[0])
plot([0,180],[0,0],color="cyan",linewidth = 2,linestyle="-.")
xlabel("x [m]")
ylabel('Depth [m]')
grid('on')
title("LIP-1B datas")
axis([40,180,1.5-4,4-3.8+1])
legend()
show()
